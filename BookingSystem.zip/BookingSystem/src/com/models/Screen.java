package com.models;

public class Screen {
	 private int id;
	    private String name;
	    private int seatCapacity;
	    private int availableSeats;
	    private String screenType;
		public Screen() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getSeatCapacity() {
			return seatCapacity;
		}
		public void setSeatCapacity(int seatCapacity) {
			this.seatCapacity = seatCapacity;
		}
		public int getAvailableSeats() {
			return availableSeats;
		}
		public void setAvailableSeats(int availableSeats) {
			this.availableSeats = availableSeats;
		}
		public String getScreenType() {
			return screenType;
		}
		public void setScreenType(String screenType) {
			this.screenType = screenType;
		}
		public Screen(int id, String name, int seatCapacity, int availableSeats, String screenType) {
			super();
			this.id = id;
			this.name = name;
			this.seatCapacity = seatCapacity;
			this.availableSeats = availableSeats;
			this.screenType = screenType;
		}
		@Override
		public String toString() {
			return "Screen [id=" + id + ", name=" + name + ", seatCapacity=" + seatCapacity + ", availableSeats="
					+ availableSeats + ", screenType=" + screenType + "]";
		}
	    
}
