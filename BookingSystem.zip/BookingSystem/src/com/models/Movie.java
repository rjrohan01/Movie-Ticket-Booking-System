package com.models;

public class Movie {
    private int id;
    private String title;
    private String genre;
    private String showtime;
    private String img;
	public Movie(int id, String title, String genre, String showtime, String img) {
		super();
		this.id = id;
		this.title = title;
		this.genre = genre;
		this.showtime = showtime;
		this.img = img;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", title=" + title + ", genre=" + genre + ", showtime=" + showtime + ", img=" + img
				+ "]";
	}

    
}