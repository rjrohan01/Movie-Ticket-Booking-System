package com.models;

import java.util.Date;

public class Booking {
    private int id;
    private int userId;
    private int movieId;
    private int seatId;
    private Date bookingTime;
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Booking(int id, int userId, int movieId, int seatId, Date bookingTime) {
		super();
		this.id = id;
		this.userId = userId;
		this.movieId = movieId;
		this.seatId = seatId;
		this.bookingTime = bookingTime;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the movieId
	 */
	public int getMovieId() {
		return movieId;
	}
	/**
	 * @param movieId the movieId to set
	 */
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	/**
	 * @return the seatId
	 */
	public int getSeatId() {
		return seatId;
	}
	/**
	 * @param seatId the seatId to set
	 */
	public void setSeatId(int seatId) {
		this.seatId = seatId;
	}
	/**
	 * @return the bookingTime
	 */
	public Date getBookingTime() {
		return bookingTime;
	}
	/**
	 * @param bookingTime the bookingTime to set
	 */
	public void setBookingTime(Date bookingTime) {
		this.bookingTime = bookingTime;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Booking [id=" + id + ", userId=" + userId + ", movieId=" + movieId + ", seatId=" + seatId
				+ ", bookingTime=" + bookingTime + ", getId()=" + getId() + ", getUserId()=" + getUserId()
				+ ", getMovieId()=" + getMovieId() + ", getSeatId()=" + getSeatId() + ", getBookingTime()="
				+ getBookingTime() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
    
    // Getters and setters
    
}
