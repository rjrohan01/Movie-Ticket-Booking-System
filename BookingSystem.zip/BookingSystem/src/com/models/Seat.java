package com.models;

public class Seat {
    private int id;
    private int screenId;
    private String seatNumber;
    private boolean isBooked;
	public Seat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Seat(int id, int screenId, String seatNumber, boolean isBooked) {
		super();
		this.id = id;
		this.screenId = screenId;
		this.seatNumber = seatNumber;
		this.isBooked = isBooked;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getScreenId() {
		return screenId;
	}
	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public boolean isBooked() {
		return isBooked;
	}
	public void setBooked(boolean isBooked) {
		this.isBooked = isBooked;
	}
	@Override
	public String toString() {
		return "Seat [id=" + id + ", screenId=" + screenId + ", seatNumber=" + seatNumber + ", isBooked=" + isBooked
				+ "]";
	}
    
}