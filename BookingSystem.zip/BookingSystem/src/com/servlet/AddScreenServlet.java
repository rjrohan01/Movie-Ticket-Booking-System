package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.utils.DatabaseUtil;

@WebServlet("/addScreen")
public class AddScreenServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String screenName = request.getParameter("screenName");
        int seatCount = Integer.parseInt(request.getParameter("seatCount"));
        
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String insertScreenSql = "INSERT INTO screens (name, seat_capacity, available_seats, screen_type) VALUES (?, ?, ?, ?)";
            try (PreparedStatement screenStatement = connection.prepareStatement(insertScreenSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                screenStatement.setString(1, screenName);
                screenStatement.setInt(2, seatCount);
                screenStatement.setInt(3, seatCount); // Initially, all seats are available
                screenStatement.setString(4, "Standard"); // Assuming a default screen type
                screenStatement.executeUpdate();
                
                // Get the generated screen id
                int screenId = -1;
                try (ResultSet generatedKeys = screenStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        screenId = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Failed to retrieve generated screen id.");
                    }
                }
                
                // Insert seats into seats table for the new screen
                String insertSeatsSql = "INSERT INTO seats (screen_id, seat_number, is_booked) VALUES (?, ?, false)";
                try (PreparedStatement seatsStatement = connection.prepareStatement(insertSeatsSql)) {
                    for (int i = 1; i <= seatCount; i++) {
                        seatsStatement.setInt(1, screenId);
                        seatsStatement.setString(2, "Seat " + i);
                        seatsStatement.addBatch();
                    }
                    seatsStatement.executeBatch();
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Handle potential errors in a better way
        }
        
        // Redirect to a confirmation page or refresh current page
        response.sendRedirect("admin.jsp"); // Redirect back to admin panel
    }
}
