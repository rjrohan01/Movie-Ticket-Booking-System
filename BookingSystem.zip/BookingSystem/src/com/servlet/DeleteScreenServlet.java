package com.servlet;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.utils.DatabaseUtil;

@WebServlet("/deleteScreen")
public class DeleteScreenServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String screenIdStr = request.getParameter("screenId");
        if (screenIdStr != null) {
            int screenId = Integer.parseInt(screenIdStr);
            
            // Perform deletion from the database (e.g., using JDBC)
            try {
            	Class.forName("com.mysql.cj.jdbc.Driver");
            	Connection connection = DatabaseUtil.getConnection();
            	String sql = "DELETE FROM screens WHERE id = ?";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, screenId);
                    statement.executeUpdate();
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace(); // Handle potential errors in a better way
            }
            
            // Redirect to a confirmation page or refresh current page
            response.sendRedirect("admin.jsp"); // Redirect back to admin panel
        }
    }
}

