package com.servlet;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.utils.DatabaseUtil;

import java.io.*;
import java.sql.*;

@WebServlet("/deleteBooking")
public class DeleteBookingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve bookingId parameter
        String bookingIdStr = request.getParameter("bookingId");
        if (bookingIdStr != null) {
            int bookingId = Integer.parseInt(bookingIdStr);

            // Delete from database
            Connection conn = null;
            PreparedStatement stmt = null;
            try {
            	try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	Connection connection = DatabaseUtil.getConnection();
                String sql = "DELETE FROM bookings WHERE id=?";
                stmt = connection.prepareStatement(sql);
                stmt.setInt(1, bookingId);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    // Redirect to the admin panel or refresh the page
                    response.sendRedirect("admin.jsp");
                } else {
                    // Handle deletion failure
                    response.getWriter().println("Failed to delete booking.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle database errors
                response.getWriter().println("Database error: " + e.getMessage());
            } finally {
                // Close resources
                try {
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
