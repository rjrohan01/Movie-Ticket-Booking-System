package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.utils.DatabaseUtil;

@WebServlet("/addMovie")
public class AddMovieServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String genre = request.getParameter("genre");
        String showtimeStr = request.getParameter("showtime");
        String img = request.getParameter("img");

        // Insert into the database using JDBC
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String sql = "INSERT INTO movies (title, genre, showtime ,img) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, title);
                statement.setString(2, genre);
                statement.setString(3, showtimeStr);
                statement.setString(4, img);
                statement.executeUpdate();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Handle potential SQL errors in a better way
            // Redirect back to admin panel with error message or flag
            response.sendRedirect("admin.jsp?error=DatabaseError");
            return;
        }

        // Redirect to a confirmation page or refresh current page
        response.sendRedirect("admin.jsp?success=MovieAdded"); // Redirect back to admin panel with success message
    }
}
