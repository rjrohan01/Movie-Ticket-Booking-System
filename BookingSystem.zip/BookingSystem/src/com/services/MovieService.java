package com.services;

import com.models.Movie;
import com.utils.DatabaseUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MovieService {
    
    // Method to add a new movie to the database
    public boolean addMovie(Movie movie) {
    	
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String query = "INSERT INTO movies (title, genre, showtime, img) VALUES (?,?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, movie.getTitle());
            statement.setString(2, movie.getGenre());
            statement.setString(3, movie.getShowtime());
            statement.setString(4, movie.getImg());
            int result = statement.executeUpdate();
            return result > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Method to get all movies from the database
    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        try{
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String query = "SELECT * FROM movies";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Movie movie = new Movie();
                movie.setId(resultSet.getInt("id"));
                movie.setTitle(resultSet.getString("title"));
                movie.setGenre(resultSet.getString("genre"));
                movie.setShowtime(resultSet.getString("showtime"));
                movie.setImg(resultSet.getString("img"));
                movies.add(movie);
                System.out.print("Movies"+movie.getId() + movie.getTitle());
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return movies;
    }
}
