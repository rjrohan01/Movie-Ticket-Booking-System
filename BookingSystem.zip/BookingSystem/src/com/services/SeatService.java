package com.services;

import com.models.Seat;
import com.utils.DatabaseUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SeatService {

    // Method to update seat status to booked
    public void updateSeatStatus(int seatId, boolean isBooked) {
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String sql = "UPDATE seats SET is_booked = ? WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setBoolean(1, isBooked);
                statement.setInt(2, seatId);
                statement.executeUpdate();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Handle potential errors in a better way
        }
    }

    // Method to get available seats
    public List<Seat> getAvailableSeats(int movieId) {
        List<Seat> seats = new ArrayList<>();
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String sql = "SELECT * FROM seats WHERE screen_id = ? AND is_booked = false";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, movieId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Seat seat = new Seat();
                        seat.setId(rs.getInt("id"));
                        seat.setScreenId(rs.getInt("screen_id"));
                        seat.setSeatNumber(rs.getString("seat_number"));
                        seat.setBooked(rs.getBoolean("is_booked"));
                        seats.add(seat);
                    }
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return seats;
    }
}
