package com.services;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.models.Booking;
import com.utils.DatabaseUtil;

public class BookingService {
    public boolean createBooking(Booking booking) {
    	
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DatabaseUtil.getConnection();
            String sql = "INSERT INTO bookings (user_id, movie_id, seat_id, booking_time) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, booking.getUserId());
            stmt.setInt(2, booking.getMovieId());
            stmt.setInt(3, booking.getSeatId());
            stmt.setTimestamp(4, new java.sql.Timestamp(booking.getBookingTime().getTime()));
            stmt.executeUpdate();
            return true;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}
