package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.models.User;
import com.services.UserService;

@WebServlet("/user")
public class UserController extends HttpServlet {
    private UserService userService = new UserService();
    

    public UserController() {
		super();
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("register".equals(action)) {
            User user = new User();
            user.setName(request.getParameter("name"));
            user.setEmail(request.getParameter("email"));
            user.setPassword(request.getParameter("password"));
            if (userService.register(user)) {
                response.sendRedirect("login.jsp");
            } else {
                response.sendRedirect("register.jsp");
            }
        } else if ("login".equals(action)) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            User user = userService.login(email, password);
            System.out.println("User" + user );
            if (user != null) {
                request.getSession().setAttribute("user", user);
                response.sendRedirect("movies.jsp");
            } else {
                response.sendRedirect("login.jsp");
            }
        }
        else if ("admin".equals(action)) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            User user = userService.login(email, password);
            System.out.println("User" + user );
            if (email.equals("Saloni") && password.equals("123")) {
                //request.getSession().setAttribute("user", user);
                response.sendRedirect("admin.jsp");
            } else {
                response.sendRedirect("login.jsp");
            }
        }
    }
}

