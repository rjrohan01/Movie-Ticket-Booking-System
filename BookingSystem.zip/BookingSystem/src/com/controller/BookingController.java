package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.models.Booking;
import com.models.Movie;
import com.models.Seat;
import com.models.User;
import com.services.BookingService;
import com.services.MovieService;
import com.services.SeatService;

@WebServlet("/booking")
public class BookingController extends HttpServlet {
    MovieService movieService = new MovieService();
    SeatService seatService = new SeatService();
    BookingService bookingService = new BookingService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("selectMovie".equals(action)) {
        	 List<Movie> movies = movieService.getAllMovies();
             System.out.println("Movies" + movies);
             request.setAttribute("movies", movies);
            request.getRequestDispatcher("movies.jsp").forward(request, response);
        } else if ("selectSeats".equals(action)) {
        		int movieId = Integer.parseInt(request.getParameter("movieId"));
        		List<Seat> seats = seatService.getAvailableSeats(movieId);
        		System.out.println("Seats" + seats);
                request.setAttribute("seats", seats);
                request.setAttribute("movieId", movieId);
                request.getRequestDispatcher("booking.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String action = request.getParameter("action");
        PrintWriter  out = response.getWriter();
        if ("book".equals(action)) {
            int movieId = Integer.parseInt(request.getParameter("movieId"));
            int seatId = Integer.parseInt(request.getParameter("seatId"));
            User user = (User) request.getSession().getAttribute("user");

            // Get available seats to verify if selected seat is available
            List<Seat> availableSeats = seatService.getAvailableSeats(movieId);

            boolean seatAvailable = false;
            for (Seat seat : availableSeats) {
                if (seat.getId() == seatId && !seat.isBooked()) {
                    seatAvailable = true;
                    break;
                }
            }
            System.out.println(movieId + " " + seatId + user);
            if (!seatAvailable) {
				// Handle case where selected seat is not available
                out.println("<script type='text/javascript'>");
                out.println("alert('Seat is not Available..');");
                out.println("</script>");
                response.sendRedirect("movies.jsp");
                return;
            }

            // Create booking object
            Booking booking = new Booking();
            booking.setUserId(user.getId());
            booking.setMovieId(movieId);
            booking.setSeatId(seatId);
            booking.setBookingTime(new Date());

            // Perform booking in the database
            if (bookingService.createBooking(booking)) {
                // Mark the seat as booked
                seatService.updateSeatStatus(seatId, true);

                // Redirect to confirmation page
                response.sendRedirect("confirmation.jsp");
            } else {
                // Handle case where booking creation failed
            	 out.println("<script type='text/javascript'>");
                 out.println("alert('Please Choose wisely..');");
                 out.println("</script>");
                //response.sendRedirect("booking.jsp?error=booking_failed");
            }
        }
    }
}

