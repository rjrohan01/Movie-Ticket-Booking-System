package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.models.Movie;
import com.services.MovieService;

@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
    private MovieService movieService = new MovieService();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action.equals("updateMovies")) {
            String title = request.getParameter("movie");
            String genre = request.getParameter("genre");
            String showtime = request.getParameter("showtime");
            String img = request.getParameter("img");
            Movie movie = new Movie();
            movie.setTitle(title);
            movie.setGenre(genre);
            movie.setShowtime(showtime);
            movie.setImg(img);
            movieService.addMovie(movie);
            response.sendRedirect("admin.jsp");
        }
    }
}
